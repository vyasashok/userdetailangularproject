module.exports = {
  "database_path" : "F://angular/userdetailproject/server/db/userrecord.db",
  "IP_Address" : "http://localhost:4200",
}